# MESÓN REAL DE PLATA
- HomePage (check)
- Hacienda
- Habitaciones
- Eventos
- Contacto
- Reservar
- Aviso de privacidad
- Políticas de cancelación