<?php 
    // define('URL', 'https://mesonrealdeplata.com/');
    define('URL', 'http://localhost:8888/real-plata/');

    //$URL = 'https://mesonrealdeplata.com/';
?>