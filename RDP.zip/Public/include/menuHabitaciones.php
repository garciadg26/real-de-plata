                    <ul class="list_habitaciones">
                        <a href="junior-suite.php" class="item_suite">
                            <li>Junior Suite</li>
                        </a>
                        <a href="master-suite.php" class="item_suite active">
                            <li>Master Suite</li>
                        </a>
                        <a href="superior-suite.php" class="item_suite">
                            <li>Superior Suite</li>
                        </a>
                    </ul>